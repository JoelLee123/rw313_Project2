package org.example.p2_joel;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.function.BiConsumer;

/**
 * Handles UDP-based file reception, packet tracking, and missing packet
 * management.
 */
public class RBUDP_Receiver {

    private DatagramSocket socket; // UDP socket for receiving packets
    private HashSet<Integer> receivedSequences = new HashSet<>(); // Tracks received packet sequences
    private InetAddress senderAddress; // Sender's IP address
    private int senderPort; // Sender's port number
    private FileOutputStream fileOutputStream; // Output stream for writing received data
    private String destinationFilePath; // Path to save the received file
    private String originalFileName; // Original file name
    private String destinationDirectory; // Directory to save the received file

    private int numPackets; // Total number of packets expected

    private static final int BLAST_SIZE = 10; // Number of packets in a blast
    private volatile boolean running = true; // Flag to control receiver's running state

    private BiConsumer<Long, Long> progressUpdate; // Callback for progress updates

    /**
     * Constructs a new RBUDP_Receiver instance.
     *
     * @param port                 The UDP port to listen on.
     * @param destinationDirectory The directory where the received file will be
     *                             saved.
     * @throws SocketException       If there is an error creating the UDP socket.
     * @throws FileNotFoundException If the destination directory is invalid.
     */
    public RBUDP_Receiver(int port, String destinationDirectory) throws SocketException, FileNotFoundException {
        this.socket = new DatagramSocket(port);
        this.destinationDirectory = destinationDirectory;

        // Create destination directory if it doesn't exist
        File directory = new File(destinationDirectory);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Generate a unique file name based on timestamp
        String fileName = "received_file_" + System.currentTimeMillis() + ".dat";
        String filePath = destinationDirectory + File.separator + fileName;

        this.fileOutputStream = new FileOutputStream(filePath);
    }

    public RBUDP_Receiver() {
        // Default constructor
    }

    /**
     * Sets the callback for progress updates during file reception.
     *
     * @param callback The BiConsumer that will be called with the number of
     *                 received packets and total packets.
     */
    public void setProgressUpdateCallback(BiConsumer<Long, Long> callback) {
        this.progressUpdate = callback;
    }

    /**
     * Starts receiving packets and writing data to the file.
     *
     * @throws IOException            If there is an error receiving or writing
     *                                data.
     * @throws ClassNotFoundException If there is an error deserializing the
     *                                received data.
     */
    public void receivePackets() throws IOException, ClassNotFoundException {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        socket.receive(packet); // Receive initial packet with file details
        ByteArrayInputStream byteStream = new ByteArrayInputStream(packet.getData(), 0, packet.getLength());
        ObjectInputStream objStream = new ObjectInputStream(byteStream);
        Data data = (Data) objStream.readObject();

        numPackets = data.getPacketTotal(); // Get total number of packets

        socket.receive(packet); // Receive original file name
        originalFileName = new String(packet.getData(), 0, packet.getLength());

        // Create FileOutputStream with original file name
        String filePath = destinationDirectory + File.separator + originalFileName;
        fileOutputStream = new FileOutputStream(filePath);

        while (running) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());

                if (message.equals("ACK_REQUEST")) {
                    sendAcknowledgement(); // Send acknowledgement for received packets
                } else {
                    senderAddress = packet.getAddress();
                    senderPort = packet.getPort();
                    processPacket(packet); // Process received packet

                    // Send acknowledgement after receiving a full blast
                    if (receivedSequences.size() % BLAST_SIZE == 0) {
                        sendAcknowledgement();
                    }
                }
            } catch (SocketException e) {
                // Socket closed, exit loop
                break;
            }
        }
    }

    private void processPacket(DatagramPacket packet) throws IOException {
        byte[] packetBytes = packet.getData();

        // Extract sequence number from first 4 bytes
        ByteBuffer wrapped = ByteBuffer.wrap(packetBytes, 0, 4);
        int sequenceNumber = wrapped.getInt();

        // Extract data from remaining bytes
        byte[] data = Arrays.copyOfRange(packetBytes, 4, packet.getLength());

        fileOutputStream.write(data); // Write data to file

        receivedSequences.add(sequenceNumber); // Add sequence number to received set

        // Invoke progress update callback if set
        if (progressUpdate != null) {
            progressUpdate.accept((long) receivedSequences.size(), (long) numPackets);
        }
    }

    private void sendAcknowledgement() throws IOException {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        ObjectOutputStream objStream = new ObjectOutputStream(byteStream);
        objStream.writeObject(receivedSequences); // Serialize received sequences
        byte[] ackData = byteStream.toByteArray();
        DatagramPacket ackPacket = new DatagramPacket(ackData, ackData.length, senderAddress, senderPort);
        socket.send(ackPacket); // Send acknowledgement packet
    }

    /**
     * Stops the receiver from receiving further packets.
     */
    public void stopReceiving() {
        running = false;
    }

    /**
     * Closes the file output stream and the UDP socket.
     *
     * @throws IOException If there is an error closing the streams.
     */
    public void close() throws IOException {
        if (fileOutputStream != null) {
            fileOutputStream.close(); // Close file output stream
        }
        if (socket != null) {
            socket.close(); // Close UDP socket
        }
    }
}