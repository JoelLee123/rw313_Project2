package org.example.p2_joel;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Handles the logging of file transfer experiments.
 */
public class TransferExperiment {
    private static final String LOG_FILE_PATH = "transfer_experiments.log"; // Path of the log file

    /**
     * Runs a file transfer experiment and logs the details.
     *
     * @param protocol     The protocol used for the file transfer (e.g., TCP,
     *                     RBUDP).
     * @param fileSize     The size of the file being transferred, in bytes.
     * @param transferTime The time taken for the file transfer, in milliseconds.
     */
    public static void runExperiment(String protocol, long fileSize, long transferTime) {
        double fileSizeMB = fileSize / (1024.0 * 1024.0); // Convert file size to MB
        double transferRate = fileSizeMB / (transferTime / 1000.0); // Calculate transfer rate in MB/s

        // Construct the log entry string
        String logEntry = String.format(
                "Protocol: %s\tFile Size (MB): %.2f\tTransfer Time (s): %.2f\tTransfer Rate (MB/s): %.2f",
                protocol, fileSizeMB, transferTime / 1000.0, transferRate);
        writeToLogFile(logEntry); // Write the log entry to the log file
    }

    /**
     * Writes the given log entry to the log file.
     *
     * @param logEntry The log entry string to be written.
     */
    private static void writeToLogFile(String logEntry) {
        try (FileWriter writer = new FileWriter(LOG_FILE_PATH, true)) { // Open the log file in append mode
            writer.write(logEntry + System.lineSeparator()); // Write the log entry and a new line
        } catch (IOException e) {
            e.printStackTrace(); // Print the exception stack trace if an error occurs
        }
    }
}