package org.example.p2_joel;

import java.io.*;
import java.net.Socket;
import java.util.function.BiConsumer;

/**
 * Handles the sending of files over a TCP connection.
 */
public class TCP_Sender {

    private int chunkCounter; // Counter for tracking sent chunks
    private Socket socket; // Socket for sending data
    private InputStream in; // Input stream for reading file data
    private long totalBytesSent; // Total number of bytes sent
    private String filePath; // Path of the file to be sent
    private OutputStream out; // Output stream for sending data
    private String serverIP; // Server IP address
    private FileInputStream fileInputStream; // Input stream for reading the file
    private ObjectOutputStream objectOutputStream; // Object output stream for sending metadata

    // Callback for updating the progress bar in the GUI
    private BiConsumer<Integer, Integer> progressUpdateCallback;

    /**
     * Sets the callback for updating the progress bar.
     *
     * @param progressUpdateCallback A BiConsumer that takes the current progress
     *                               and total progress,
     *                               and updates the progress bar accordingly.
     */
    public void setProgressUpdate(BiConsumer<Integer, Integer> progressUpdateCallback) {
        this.progressUpdateCallback = progressUpdateCallback;
    }

    /**
     * Sets the IP address of the server.
     *
     * @param serverIP The IP address of the server.
     */
    public void setSenderIP(String serverIP) {
        this.serverIP = serverIP;
    }

    /**
     * Sets the file to be sent over the network.
     *
     * @param filePath The path of the file to be sent.
     */
    public void setFile(String filePath) {
        try {
            this.filePath = filePath;
            this.fileInputStream = new FileInputStream(this.filePath);
        } catch (FileNotFoundException e) {
            System.out.println("The file could not be found");
        }
    }

    /**
     * Initializes the ObjectOutputStream used for sending objects over TCP.
     */
    public void initSenderTCP() {
        try {
            // Check if objectOutputStream is null to avoid null pointer exceptions
            if (objectOutputStream == null) {
                objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            }
        } catch (IOException e) {
            System.out.println("IOException occurred in initSenderTCP()");
        }
    }

    /**
     * Sets up the TCP socket connection.
     */
    public void initSocketTCP() {
        try {
            // Initialize the socket if it's null or not connected
            if (socket == null || !socket.isConnected()) {
                socket = new Socket(serverIP, 1234); // Connect to the server
                socket.setTcpNoDelay(true); // Disable Nagle's algorithm for better performance
            }
        } catch (IOException e) {
            System.out.println("IOException occurred in initSocketTCP()");
        }
    }

    /**
     * Sends a file over the TCP connection.
     */
    public void sendTCP() {
        try {
            long startTime = System.currentTimeMillis(); // Start time for calculating transfer rate
            chunkCounter = 0;
            int bytesRead;
            byte[] buffer = new byte[8 * 1024]; // Buffer for reading file data

            File file = new File(filePath);
            fileInputStream = new FileInputStream(file);

            // Extract the file name from the file path
            String fileName = filePath.substring(filePath.lastIndexOf("/") + 1);
            Data data = new Data(fileName, file.length()); // Create Data object with file metadata
            System.out.println("Wrapping Data...");

            // Send the Data object over TCP
            objectOutputStream.writeObject(data);
            objectOutputStream.flush();

            // Prepare to write to the output stream
            out = socket.getOutputStream();
            System.out.println("Sending Data...");

            // Read data from FileInputStream and send it over TCP
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
                out.flush();
                totalBytesSent += bytesRead; // Update total bytes sent

                // Update progress bar every other chunk
                if (chunkCounter % 2 == 0) {
                    progressUpdateCallback.accept(chunkCounter, data.getNumChunks());
                }
                chunkCounter++;
            }

            long endTime = System.currentTimeMillis(); // End time for calculating transfer rate
            long transferTime = endTime - startTime;

            TransferExperiment.runExperiment("TCP", data.getFileSize(), transferTime); // Run experiment
        } catch (IOException e) {
            System.out.println("An IO Exception occurred in senderTCP");
            e.printStackTrace();
        }
    }
}