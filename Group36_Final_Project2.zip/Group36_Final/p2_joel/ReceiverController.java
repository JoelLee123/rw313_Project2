package org.example.p2_joel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.SocketException;
import java.util.function.BiConsumer;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

/**
 * Manages the UI and operations for receiving files.
 */
public class ReceiverController {

    // FXML components
    @FXML
    private ToggleGroup Group;
    @FXML
    private Label lblSelectedLocation;
    @FXML
    private Button rBtnStorage;
    @FXML
    private TextField rFieldIP;
    @FXML
    private ProgressBar rProgBar;
    @FXML
    private RadioButton rRadioRBUDP;
    @FXML
    private RadioButton rRadioTCP;

    private TCP_Receiver tcpReceiver; // Handles TCP file reception
    private RBUDP_Receiver rbudpReceiver; // Handles RBUDP file reception
    public volatile Thread tcpThread; // Thread for TCP reception
    public volatile Thread rbudpThread; // Thread for RBUDP reception
    public boolean isActive = false; // Flag indicating receiver activity
    private String destinationPath; // Path for storing received files

    /**
     * Sets up the receiver components.
     */
    public void initialize() {
        tcpReceiver = new TCP_Receiver(); // Initialize TCP receiver
        rbudpReceiver = new RBUDP_Receiver(); // Initialize RBUDP receiver
    }

    /**
     * Displays a warning message to the user.
     *
     * @param message The warning message to display.
     */
    public static void showWarning(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Receiver Warning");
            alert.setHeaderText(message);
            alert.showAndWait();
        });
    }

    /**
     * Allows the user to select a directory for storing received files.
     *
     * @param event The event triggered by clicking the Storage button.
     */
    @FXML
    public void handleStorageSelection(ActionEvent event) {
        Stage stage = (Stage) rBtnStorage.getScene().getWindow();
        DirectoryChooser chooser = new DirectoryChooser();
        File directory = chooser.showDialog(stage);
        if (directory == null) {
            showWarning("Please select a directory to store received files.");
        } else {
            destinationPath = getDirectoryPath(directory); // Get selected directory path
            tcpReceiver.setDirectory(destinationPath); // Set directory for TCP receiver
        }
    }

    /**
     * Initiates the file reception process based on the selected protocol.
     *
     * @param event The event triggered by clicking the Start button.
     * @throws FileNotFoundException If the destination directory is invalid.
     */
    public void startReception(ActionEvent event) throws FileNotFoundException {
        isActive = true;
        // Validate input fields
        if (rFieldIP.getText().isEmpty() || lblSelectedLocation.getText().equals("Storage Location")) {
            showWarning("IP Address cannot be empty and a storage location must be set");
        } else {
            if (rRadioTCP.isSelected()) {
                // Start TCP receiver thread
                tcpThread = new Thread(() -> {
                    tcpReceiver.initServerSockTCP(); // Initialize TCP server socket
                    tcpReceiver.initReceiverTCP(); // Set up TCP receiver

                    // Configure progress update callback
                    tcpReceiver.setProgressUpdateCallback((currentSize, totalSize) -> {
                        Platform.runLater(() -> {
                            double progress = (double) currentSize / totalSize;
                            rProgBar.setProgress(progress);
                        });
                    });

                    while (isActive) {
                        tcpReceiver.receive();
                    }
                });
                tcpThread.start();
            } else {
                setupRBUDPReceiver();

                // Configure progress update callback for RBUDP
                rbudpReceiver.setProgressUpdateCallback((receivedPackets, totalPackets) -> {
                    Platform.runLater(() -> {
                        double progress = (double) receivedPackets / totalPackets;
                        rProgBar.setProgress(progress);
                    });
                });
            }
            System.out.println("[RBUDP] Awaiting Connection...");
        }
    }

    /**
     * Retrieves the absolute path of the selected directory.
     *
     * @param directory The selected directory.
     * @return The absolute path of the directory.
     */
    public String getDirectoryPath(File directory) {
        String path = directory.getAbsolutePath();
        int lastSeparatorIndex = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
        if (lastSeparatorIndex == -1) {
            lastSeparatorIndex = 0;
        } else {
            lastSeparatorIndex++;
        }
        String displayPath = ".." + path.substring(lastSeparatorIndex) + "/";
        path = path + "/";
        lblSelectedLocation.setText(displayPath); // Update UI with selected path
        return path;
    }

    /**
     * Configures and starts the RBUDP receiver.
     *
     * @throws FileNotFoundException If the destination directory is invalid.
     */
    private void setupRBUDPReceiver() throws FileNotFoundException {
        try {
            int udpPort = 4044; // Port for RBUDP reception
            String receivedFilesDirectory = destinationPath;

            rbudpReceiver = new RBUDP_Receiver(udpPort, receivedFilesDirectory);

            // Start RBUDP receiver thread
            rbudpThread = new Thread(() -> {
                try {
                    isActive = true;
                    rbudpReceiver.receivePackets(); // Start receiving packets
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                    isActive = false; // Deactivate receiver on exception
                }
            });
            rbudpThread.start();
        } catch (SocketException e) {
            e.printStackTrace();
            showWarning("Failed to initialize RBUDP receiver: " + e.getMessage());
        }
    }

    /**
     * Interrupts the receiver threads, effectively stopping the reception process.
     */
    public void interruptThreads() {
        // Interrupt TCP thread
        Thread interruptTCPThread = tcpThread;
        tcpThread = null;
        if (interruptTCPThread != null) {
            interruptTCPThread.interrupt();
        }

        // Interrupt RBUDP thread
        Thread interruptRBUDPThread = rbudpThread;
        rbudpThread = null;
        if (interruptRBUDPThread != null) {
            interruptRBUDPThread.interrupt();
        }
    }

    /**
     * Stops the ongoing file reception process.
     *
     * @param event The event triggered by clicking the Stop button.
     * @throws IOException If an I/O error occurs while closing the TCP connection.
     */
    @FXML
    public void stopReception(ActionEvent event) throws IOException {
        isActive = false; // Deactivate receiver
        interruptThreads();
        tcpReceiver.closeTCP(); // Close TCP connection

        // Stop RBUDP receiver
        rbudpReceiver.stopReceiving();
        rbudpReceiver.close();
    }
}