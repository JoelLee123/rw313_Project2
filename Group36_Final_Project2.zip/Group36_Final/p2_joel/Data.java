/**
* This class represents the data that needs to be transferred between the Sender and Receiver
* for the experiments. It serves as the object that will be sent over TCP and RBUDP connections.
*
* The Data class encapsulates various properties related to the file being transferred, such as
* file name, file size, chunk information, packet details, and the state of the transfer.
* It also provides methods to set and get these properties.
*
* The class implements the Serializable interface, allowing its instances to be serialized
* for transmission over the network.
*/
package org.example.p2_joel;

import java.io.Serializable;

public class Data implements Serializable {

    private State state;
    private String fileName;
    private String sequenceList;
    private int numChunks;
    private int blastSize;
    private int packetSize;
    private int packetTotal;
    private int totalPackets;
    private long fileSize;

    /**
     * Constructor used by TCP.
     *
     * @param fileName The name of the file being sent.
     * @param fileSize The size of the file in bytes.
     */
    public Data(String fileName, long fileSize) {
        this.fileSize = fileSize;
        this.fileName = fileName;
        numChunks = (int) (fileSize / (8 * 1024));
    }

    /**
     * Constructor with additional parameters for packet-related information.
     *
     * @param filename     The name of the file being sent.
     * @param fileSize     The size of the file in bytes.
     * @param packetSize   The size of each packet in bytes.
     * @param blastLength  The number of packets in a blast.
     * @param totalPackets The total number of packets for the file transfer.
     */
    public Data(String filename, long fileSize, int packetSize, int blastLength, int totalPackets) {
        this.fileName = filename;
        this.fileSize = fileSize;
        this.packetSize = packetSize;
        this.blastSize = blastLength;
        this.totalPackets = totalPackets;
    }

    /**
     * Default constructor.
     */
    public Data() {
    }

    /**
     * Enum representing state of transfer.
     * It can either have no missing packets or it can.
     */
    public enum State {
        COMPLETE_PACKETS, MISSING_PACKETS
    }

    public int getNumChunks() {
        return numChunks;
    }

    public int getBlastSize() {
        return blastSize;
    }

    public long getFileSize() {
        return fileSize;
    }

    public int getPacketSize() {
        return packetSize;
    }

    public int getPacketTotal() {
        return packetTotal;
    }

    public String getFileName() {
        return fileName;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public void setSequenceList(String missingSeqNum) {
        if (missingSeqNum != null) {
            sequenceList = missingSeqNum;
        } else {
            System.out.println("missingSeqNum is null");
        }
    }

    public String getSequenceList() {
        return this.sequenceList;
    }
}