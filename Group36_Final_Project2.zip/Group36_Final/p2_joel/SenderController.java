package org.example.p2_joel;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.*;

/**
 * Manages the UI and operations for sending files over TCP or RBUDP.
 */
public class SenderController {
    // FXML components
    @FXML
    private ToggleGroup ToggleGroup;

    @FXML
    private Button sBtnDirectory;

    @FXML
    private Button sBtnSend;

    @FXML
    private TextField sFieldIP;

    @FXML
    private Label sLabelFile;

    @FXML
    private ProgressBar sProgBar;

    @FXML
    private RadioButton sRadioRBUDP;

    @FXML
    private RadioButton sRadioTCP;

    // Sender components
    private TCP_Sender tcpSender;
    private RBUDP_Sender rbudpSender;

    public String filePath;

    /**
     * Initializes the sender components and UI elements.
     */
    public void initialize() {
        tcpSender = new TCP_Sender();
        rbudpSender = new RBUDP_Sender();

        ToggleGroup protocolGroup = new ToggleGroup();
        sRadioTCP.setToggleGroup(protocolGroup);
        sRadioRBUDP.setToggleGroup(protocolGroup);
    }

    /**
     * Displays a warning message to the user.
     *
     * @param message The warning message to display.
     */
    public static void showWarning(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sender Warning!");
            alert.setHeaderText(message);
            alert.showAndWait();
        });
    }

    /**
     * Initiates the file sending process based on the selected protocol.
     *
     * @param event The event triggered by clicking the Send button.
     * @throws IOException            If an I/O error occurs during file transfer.
     * @throws ClassNotFoundException If a class is not found during object
     *                                deserialization.
     */
    @FXML
    public void sendFile(ActionEvent event) throws IOException, ClassNotFoundException {

        // Validate input fields
        if (sFieldIP.getText().isEmpty() || sLabelFile.getText().equals("File")) {
            showWarning("IP Address cannot be empty and a file must be selected");
            return;
        }

        // Handle file sending based on the selected protocol
        if (sRadioRBUDP.isSelected()) {
            rbudpSender.setInetAddress(sFieldIP.getText());
            rbudpSender.setPort(4044);
            rbudpSender.initSocket();

            // Prepare and send the file over RBUDP
            File fileToSend = new File(filePath);
            rbudpSender.setFile(fileToSend);
            rbudpSender.sendFile();
            rbudpSender.close();

            System.out.println("File Successfully written to " + filePath);
        } else {
            // Handle TCP file transfer
            System.out.println("TCP CASE HANDLED");
            tcpSender.setSenderIP(sFieldIP.getText());
            tcpSender.initSocketTCP();
            tcpSender.initSenderTCP();

            // Configure progress bar updates
            Service<Void> progressBarService = new Service<Void>() {
                @Override
                protected Task<Void> createTask() {
                    return new Task<Void>() {
                        @Override
                        protected Void call() throws Exception {
                            tcpSender.setProgressUpdate((workDone, totalWork) -> updateProgress(workDone, totalWork));
                            tcpSender.sendTCP();
                            return null;
                        }
                    };
                }
            };
            Platform.runLater(() -> progressBarService.restart());
        }
    }

    /**
     * Allows the user to select a file for sending.
     *
     * @param event The event triggered by clicking the Directory button.
     */
    @FXML
    public void selectFile(ActionEvent event) {
        System.out.println("SELECT FOLDER TEST");
        Stage stage = (Stage) sBtnDirectory.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();

        File file = fileChooser.showOpenDialog(stage);
        if (file == null) {
            showWarning("No file selected. Please select a file.");
        } else {
            filePath = getFilePath(file);
            tcpSender.setFile(filePath);
            rbudpSender.setFileDest(filePath);
        }
    }

    /**
     * Retrieves the file path and updates the file label with the file size.
     *
     * @param file The selected file.
     * @return The absolute file path.
     */
    public String getFilePath(File file) {
        String path = file.getAbsolutePath(); // Get the absolute file path
        int lastSeparatorIndex = getLastSeparatorIndex(path); // Get the index of the last path separator
        String displayPath = ".." + path.substring(lastSeparatorIndex); // Get the path to display in the UI
        long fileSize = file.length(); // Get the file size in bytes
        updateFileSizeLabel(fileSize); // Update the file size label based on the file size
        return path; // Return the absolute file path
    }

    /**
     * Gets the index of the last path separator (/ or \) in the given path.
     *
     * @param path The path string.
     * @return The index of the last path separator, or 0 if no separator is found.
     */
    private int getLastSeparatorIndex(String path) {
        int lastSeparator = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\")); // Find the index of the last path
                                                                                     // separator
        if (lastSeparator == -1) {
            lastSeparator = 0; // If no separator is found, use index 0
        } else {
            lastSeparator++; // Move the index past the separator
        }
        return lastSeparator;
    }

    /**
     * Updates the file size label based on the given file size.
     *
     * @param fileSize The size of the file in bytes.
     */
    private void updateFileSizeLabel(long fileSize) {
        double kilobytes = (double) (fileSize / 1024.0); // kilobytes
        double megabytes = kilobytes / 1024.0; // megabytes
        double gigabytes = megabytes / 1024.0; // gigabytes

        if (fileSize < 1024) {
            sLabelFile.setText(Long.toString(fileSize) + " Bytes"); // bytes
        } else if (fileSize >= 1024.0 && fileSize < 1048576.0) {
            sLabelFile.setText(String.format("%,.2f", kilobytes) + " KB"); // kilobytes
        } else if (fileSize >= 1048576.0 && fileSize < 1073741824.0) {
            sLabelFile.setText(String.format("%,.2f", megabytes) + " MB"); // megabytes
        } else if (fileSize >= 1073741824.0) {
            sLabelFile.setText(String.format("%,.2f", gigabytes) + " GB"); // gigabytes
        }
    }

}