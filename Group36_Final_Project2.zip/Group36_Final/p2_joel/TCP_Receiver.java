package org.example.p2_joel;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.function.BiConsumer;

/**
 * Handles the reception of files over TCP.
 */
public class TCP_Receiver {

    private Data data; // Data object containing file metadata
    private String dir; // Directory path for storing received files
    private int counter; // Counter for tracking received chunks
    private long fileSize; // Size of the file being received
    private int numChunks; // Number of chunks the file is divided into
    private Socket socket; // Socket for receiving data
    private InputStream in; // Input stream for reading data
    private String fileName; // Name of the file being received
    private ServerSocket sSocket; // Server socket for accepting connections
    private ObjectInputStream objIn; // Object input stream for reading metadata
    private FileOutputStream fileOut; // File output stream for writing received data
    private ObjectOutputStream objOut; // Object output stream for sending metadata

    private volatile boolean isInitialized = false; // Flag indicating if the receiver is initialized

    private BiConsumer<Long, Long> progressUpdateCallback; // Callback for progress updates

    /**
     * Initializes the TCP_Receiver instance.
     */
    public TCP_Receiver() {
        socket = null;
        sSocket = null;
        in = null;
        fileOut = null;
        objOut = null;
        objIn = null;
    }

    /**
     * Checks if the receiver is initialized.
     *
     * @return true if the receiver is initialized, false otherwise.
     */
    public boolean isInitialized() {
        return isInitialized;
    }

    /**
     * Sets the callback for progress updates.
     *
     * @param callback The BiConsumer that will be called with the number of bytes
     *                 read and total file size.
     */
    public void setProgressUpdateCallback(BiConsumer<Long, Long> callback) {
        this.progressUpdateCallback = callback;
    }

    /**
     * Receives the file over TCP.
     */
    public void receive() {
        counter = 0; // Initialize chunk counter

        try {
            byte[] buffer = new byte[8 * 1024]; // Buffer for reading data
            int bytesRead;
            long totalBytesRead = 0;
            long startTime = System.nanoTime();

            // Read metadata from the sender
            data = (Data) objIn.readObject();
            numChunks = data.getNumChunks();
            fileSize = data.getFileSize();
            fileName = data.getFileName();

            // Prepare file output stream
            fileOut = new FileOutputStream(dir + fileName);
            in = socket.getInputStream();

            System.out.println("Receiving file: " + fileName);

            // Continue reading until the entire file is received
            while (fileSize > 0) {
                bytesRead = readChunk(buffer); // Read a chunk of data
                if (bytesRead == -1)
                    break; // End of stream reached

                if (progressUpdateCallback != null) {
                    totalBytesRead += bytesRead;
                    progressUpdateCallback.accept(totalBytesRead, fileSize); // Invoke progress update callback
                }
                writeChunkToFile(buffer, bytesRead); // Write the chunk to the file
                updateProgress(bytesRead, startTime, totalBytesRead); // Update progress
            }

            printProgress(startTime, totalBytesRead); // Print final progress
            System.out.println("File reception complete: " + fileName + " saved to " + dir);

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error during file reception: " + e.getMessage());
        }
    }

    /**
     * Reads a chunk of data from the input stream.
     *
     * @param buffer The buffer to read data into.
     * @return The number of bytes read, or -1 if the end of the stream is reached.
     */
    private int readChunk(byte[] buffer) {
        try {
            int maxBytesToRead = (int) Math.min(buffer.length, fileSize); // Calculate the maximum number of bytes to
                                                                          // read
            return in.read(buffer, 0, maxBytesToRead); // Read data into the buffer
        } catch (IOException e) {
            System.out.println("IOException occurred in readChunk");
            return -1;
        }
    }

    /**
     * Writes a chunk of data to the file output stream.
     *
     * @param buffer    The buffer containing the data.
     * @param bytesRead The number of bytes to write.
     */
    private void writeChunkToFile(byte[] buffer, int bytesRead) {
        try {
            fileOut.write(buffer, 0, bytesRead); // Write data to the file
            fileSize -= bytesRead; // Update remaining file size
        } catch (IOException e) {
            System.out.println("IOException occurred in writeChunkToFile");
        }
    }

    /**
     * Updates the progress and prints the transfer rate.
     *
     * @param bytesRead      The number of bytes read in the current chunk.
     * @param startTime      The start time of the file transfer.
     * @param totalBytesRead The total number of bytes read so far.
     */
    private void updateProgress(int bytesRead, long startTime, long totalBytesRead) {
        totalBytesRead += bytesRead; // Update total bytes read
        counter++; // Increment chunk counter

        // Print transfer rate every other chunk
        if (counter % 2 == 0) {
            printProgress(startTime, totalBytesRead);
        }
    }

    /**
     * Prints the progress and transfer rate.
     *
     * @param startTime      The start time of the file transfer.
     * @param totalBytesRead The total number of bytes read so far.
     */
    private void printProgress(long startTime, long totalBytesRead) {
        long currentTime = System.nanoTime();
        double transferRate = (totalBytesRead / (1024.0 * 1024.0)) / ((currentTime - startTime) / 1000000000.0);
        System.out.printf("Progress: chunk %d of %d received at %.2f MB/s%n", counter, numChunks, transferRate);
    }

    /**
     * Initializes the TCP receiver.
     */
    public void initReceiverTCP() {
        try {
            System.out.println("[ReceiverTCP.java] Waiting for connection...");
            socket = sSocket.accept(); // Accept incoming connection
            socket.setTcpNoDelay(true); // Disable Nagle's algorithm for better performance
            System.out.println("[ReceiverTCP.java] Connection established...");
            objOut = new ObjectOutputStream(socket.getOutputStream()); // Initialize object output stream
            objIn = new ObjectInputStream(socket.getInputStream()); // Initialize object input stream
            isInitialized = true; // Set the initialized flag to true
        } catch (IOException e) {
            System.out.println("IOException occurred in initReceiverTCP");
        }
    }

    /**
     * Initializes the server socket for TCP connections.
     */
    public void initServerSockTCP() {
        try {
            // Using the same arbitrary port number as senderTCP for TCP
            sSocket = new ServerSocket(1234);
        } catch (IOException e) {
            System.out.println("An IO Exception occurred in initServerSockTCP");
            e.printStackTrace();
        }
    }

    /**
     * Closes the TCP connections and streams.
     */
    public void closeTCP() {
        try {
            if (objOut != null) {
                objOut.close(); // Close object output stream
            }
            if (objIn != null) {
                objIn.close(); // Close object input stream
            }
            if (fileOut != null) {
                fileOut.close(); // Close file output stream
            }
            if (in != null) {
                in.close(); // Close input stream
            }
            if (socket != null) {
                socket.close(); // Close socket
            }
            if (sSocket != null) {
                sSocket.close(); // Close server socket
            }
        } catch (IOException e) {
            System.out.println("An IO Exception occurred when closing TCP");
            e.printStackTrace();
        }
    }

    /**
     * Retrieves the directory path for storing received files.
     *
     * @return The directory path.
     */
    public String getDirectory() {
        return dir;
    }

    /**
     * Sets the directory path for storing received files.
     *
     * @param dir The directory path.
     */
    public void setDirectory(String dir) {
        this.dir = dir;
    }
}