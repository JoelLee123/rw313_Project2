package org.example.p2_joel;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.function.BiConsumer;

/**
 * Handles UDP-based file transfer to a remote server.
 */
public class RBUDP_Sender {

    private DatagramSocket socket; // UDP socket for sending packets
    private InetAddress serverAddress; // Server IP address
    private int serverPort; // Server port number
    private byte[] fileData; // File data to be sent
    private static final int PACKET_SIZE = 1024; // Maximum packet size
    private static final int BLAST_SIZE = 10; // Number of packets in a blast

    private String originalFileName; // Original file name
    int port; // Local port (unused)
    String fileDest; // File destination path
    FileInputStream fileInputStream; // Input stream for reading file data

    private BiConsumer<Integer, Integer> progressUpdate; // Callback for progress updates (unused)

    long totalSent; // Total bytes sent (unused)
    float currentTime, mbPerSec = 0; // Variables for calculating transfer rate (unused)
    int currentITime = 0; // Variable for calculating transfer rate (unused)

    /**
     * Default constructor.
     */
    public RBUDP_Sender() {
        // Empty constructor
    }

    /**
     * Sets the server IP address.
     *
     * @param serverIp The IP address of the server.
     */
    public void setInetAddress(String serverIp) {
        try {
            this.serverAddress = InetAddress.getByName(serverIp);
        } catch (UnknownHostException e) {
            System.out.println("Unknown host: " + serverIp);
            e.printStackTrace();
        }
    }

    /**
     * Sets the server port number.
     *
     * @param serverPort The port number of the server.
     */
    public void setPort(int serverPort) {
        this.serverPort = serverPort;
    }

    /**
     * Initializes the UDP socket and connects to the server.
     */
    public void initSocket() {
        try {
            this.socket = new DatagramSocket();
            this.socket.connect(new InetSocketAddress(serverAddress, serverPort));
            System.out.println("Connected to server at " + serverAddress + ":" + serverPort);
        } catch (SocketException e) {
            System.out.println("Error creating socket");
            e.printStackTrace();
        }
    }

    /**
     * Sets the file to be sent.
     *
     * @param file The file to be sent.
     * @throws IOException If there is an error reading the file.
     */
    public void setFile(File file) throws IOException {
        originalFileName = file.getName();
        long fileLength = file.length();
        fileData = new byte[(int) fileLength];

        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(file);
            int bytesRead = fileInputStream.read(fileData);
            if (bytesRead != fileLength) {
                throw new IOException("Could not read entire file");
            }
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Sends the file to the server.
     *
     * @throws IOException            If there is an error sending the file.
     * @throws ClassNotFoundException If there is an error deserializing the
     *                                acknowledgement.
     */
    public void sendFile() throws IOException, ClassNotFoundException {
        long startTime = System.currentTimeMillis(); // Start time for transfer rate calculation (unused)
        int numPackets = (int) Math.ceil((double) fileData.length / PACKET_SIZE); // Calculate number of packets
        Data data = new Data(originalFileName, fileData.length, PACKET_SIZE, BLAST_SIZE, numPackets); // Create Data
                                                                                                      // object

        // Send Data object
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        ObjectOutputStream objStream = new ObjectOutputStream(byteStream);
        objStream.writeObject(data);
        byte[] dataBytes = byteStream.toByteArray();
        DatagramPacket dataPacket = new DatagramPacket(dataBytes, dataBytes.length, serverAddress, serverPort);
        socket.send(dataPacket);

        // Send original file name
        byte[] fileNameBytes = originalFileName.getBytes();
        DatagramPacket fileNamePacket = new DatagramPacket(fileNameBytes, fileNameBytes.length, serverAddress,
                serverPort);
        socket.send(fileNamePacket);

        HashSet<Integer> sentSequences = new HashSet<>(); // Track sent packet sequences
        HashSet<Integer> ackedSequences = new HashSet<>(); // Track acknowledged packet sequences

        for (int i = 0; i < numPackets; i++) {
            // Calculate packet data size and create packet
            int dataLength = PACKET_SIZE;
            if ((i + 1) * PACKET_SIZE > fileData.length) {
                dataLength = fileData.length - i * PACKET_SIZE;
            }
            int packetDataSize = dataLength + 4;
            byte[] packetData = new byte[packetDataSize];

            // Add sequence number to packet
            ByteBuffer buffer = ByteBuffer.allocate(4);
            buffer.putInt(i);
            System.arraycopy(buffer.array(), 0, packetData, 0, 4);

            // Add file data to packet
            System.arraycopy(fileData, i * PACKET_SIZE, packetData, 4, dataLength);

            // Send packet
            DatagramPacket packet = new DatagramPacket(packetData, packetData.length, serverAddress, serverPort);
            socket.send(packet);
            sentSequences.add(i);

            // Request acknowledgement after sending a full blast or last packet
            if (i % BLAST_SIZE == BLAST_SIZE - 1 || i == numPackets - 1) {
                sendAcknowledgementRequest();
                boolean ackReceived = false;
                while (!ackReceived) {
                    try {
                        ackedSequences = receiveAcknowledgement();
                        ackReceived = true;
                    } catch (EOFException e) {
                        // Request retransmission if acknowledgement is incomplete
                        sendAcknowledgementRequest();
                    }
                }
                sentSequences.removeAll(ackedSequences);

                // Resend packets that were not acknowledged
                for (int sequence : sentSequences) {
                    int resendPacketStart = sequence * PACKET_SIZE;
                    int resendDataLength = PACKET_SIZE;
                    if ((sequence + 1) * PACKET_SIZE > fileData.length) {
                        resendDataLength = fileData.length - sequence * PACKET_SIZE;
                    }
                    int resendPacketDataSize = resendDataLength + 4;
                    byte[] resendPacketData = new byte[resendPacketDataSize];

                    // Re-add sequence number and file data to resend packet
                    buffer.clear();
                    buffer.putInt(sequence);
                    System.arraycopy(buffer.array(), 0, resendPacketData, 0, 4);
                    System.arraycopy(fileData, resendPacketStart, resendPacketData, 4, resendDataLength);

                    // Resend packet
                    DatagramPacket resendPacket = new DatagramPacket(resendPacketData, resendPacketData.length,
                            serverAddress, serverPort);
                    socket.send(resendPacket);
                }

                sentSequences.clear();
                ackedSequences.clear();
            }
        }

        long endTime = System.currentTimeMillis(); // End time for transfer rate calculation (unused)
        long transferTime = endTime - startTime; // Transfer time for experiment (unused)
        TransferExperiment.runExperiment("TCP", data.getFileSize(), transferTime); // Run experiment (unused)
    }

    /**
     * Receives an acknowledgement from the server.
     *
     * @return A HashSet containing the acknowledged packet sequences.
     * @throws IOException            If there is an error receiving the
     *                                acknowledgement.
     * @throws ClassNotFoundException If there is an error deserializing the
     *                                acknowledgement.
     */
    @SuppressWarnings("unchecked")
    private HashSet<Integer> receiveAcknowledgement() throws IOException, ClassNotFoundException {
        byte[] buffer = new byte[8192]; // Increase the buffer size if needed
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.receive(packet);
        ByteArrayInputStream byteStream = new ByteArrayInputStream(packet.getData(), 0, packet.getLength());
        ObjectInputStream objStream = new ObjectInputStream(byteStream);
        return (HashSet<Integer>) objStream.readObject();
    }

    /**
     * Sends an acknowledgement request to the server.
     *
     * @throws IOException If there is an error sending the request.
     */
    private void sendAcknowledgementRequest() throws IOException {
        byte[] requestData = "ACK_REQUEST".getBytes();
        DatagramPacket requestPacket = new DatagramPacket(requestData, requestData.length, serverAddress, serverPort);
        socket.send(requestPacket);
    }

    /**
     * Closes the UDP socket.
     */
    public void close() {
        if (socket != null) {
            socket.close();
        }
    }

    /**
     * Sets the file destination path and opens a FileInputStream.
     *
     * @param fileDest The path of the file to be sent.
     * @return True if the file is found, false otherwise.
     */
    public boolean setFileDest(String fileDest) {
        try {
            this.fileDest = fileDest;
            this.fileInputStream = new FileInputStream(fileDest);
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}