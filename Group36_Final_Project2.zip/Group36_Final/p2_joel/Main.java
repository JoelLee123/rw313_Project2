package org.example.p2_joel;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This is the main entry point of the program.
 * It loads and displays two separate JavaFX windows:
 * 1. Sender window: A UI for sending data or information.
 * 2. Receiver window: A UI for receiving data or information.
 *
 * The Sender and Receiver windows are loaded from their respective FXML files
 * (sender.fxml and receiver.fxml), and each window is displayed in a separate
 * Stage object with appropriate titles.
 *
 * Note: The details or data that need to be sent from the Sender to the
 * Receiver
 * should be handled within the corresponding controllers or other classes
 * responsible
 * for the communication logic.
 */
public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        // Loading Sender UI
        FXMLLoader senderLoader = new FXMLLoader(getClass().getResource("sender.fxml"));
        Parent senderRoot = senderLoader.load();
        Stage senderStage = new Stage();
        senderStage.setTitle("Sender");
        senderStage.setScene(new Scene(senderRoot));
        senderStage.show();

        // Loading Receiver UI
        FXMLLoader receiverLoader = new FXMLLoader(getClass().getResource("receiver.fxml"));
        Parent receiverRoot = receiverLoader.load();
        Stage receiverStage = new Stage();
        receiverStage.setTitle("Receiver");
        receiverStage.setScene(new Scene(receiverRoot));
        receiverStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
